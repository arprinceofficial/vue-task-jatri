<script setup>
import ProductView from './components/ProductView.vue'
</script>

<template>
	<main>
		<ProductView />
	</main>
</template>